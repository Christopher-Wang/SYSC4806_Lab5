The Github Repository: https://github.com/Christopher-Wang/SYSC4806_Lab5
The Travis-CI Repository: https://travis-ci.com/github/Christopher-Wang/SYSC4806_Lab5
The Heroku Repository: https://evening-dawn-45627.herokuapp.com/
The Heroku Link: https://evening-dawn-45627.herokuapp.com/addressbook